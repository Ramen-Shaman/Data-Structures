package org.uofm.tools;

/**
 * Enumeration to define months of the year.
 * @author tcanaday
 *
 */
public enum MonthDefinition
{
	January,
	February,
	March,
	April,
	May,
	June,
	July,
	August,
	September,
	October,
	November,
	December;
}



