package org.uofm.tools;

public class ProgramHelper 
{
	public static void ProgramDescription()
	{
		System.out.println("This program will create a delimiter file that can be later used to import into excel.");
		System.out.println("This will also allow the user to determine the place in which to create and edit the file.");
	}
	
	public static void DeveloperInformation()
	{
		System.out.println("This program was written by: Cameron Hall");
		System.out.println("Laboratory Excercise 2 ");
		System.out.println("Data Structures");
		System.out.println("Spring 2020");
		System.out.println("The University of Memphis");
	}

}
