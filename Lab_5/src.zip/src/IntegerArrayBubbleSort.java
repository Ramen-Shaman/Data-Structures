//	TECH 2261
//	Data Structures
//	Spring 2020
//	The University of Memphis
//
//	Assignment:		Laboratory Exercise #4
//	File Name:		IntegerArrayBubbleSort.java
//	Developer:		Todd S. Canaday
//	Version:		1.0
//	Compiler:		Java ver. 1.8.0_221

import java.text.DecimalFormat;
import org.uofm.tools.CreateCustomArray;
import org.uofm.tools.ProgramHelper;
import org.uofm.tools.SortingAlgorithms;

public class IntegerArrayBubbleSort
{
	public static void main(String[] args)
	{
		//	declare objects for program use...
		
		//	set the size of the int array to create...

		//	formatter used to display long numbers with commas...
		
		
		//	describe the program to the user...

		//	add a line for spacing...

		
		//	calculate the number of comparisons to be made...

		//	display the number of comparisons to the user...

		
		//	create the random int array...

		
		//	get the current timestamp before starting the method...

		//	call the bubble sort method...

		//	get the current timestamp after finishing the method...

		
		//	calculate the total time...

		
		//	add a line for spacing...
		
		
		//	display the total execution time... 
		
		//	add a line for spacing...

		
		//	display the developer information...
		
	}
	
	public static long CalculateNumberOfComparisons(long elements)
	{
		
		
		return elements;
	}
}
