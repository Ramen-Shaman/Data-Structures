package org.uofm.tools;

public class ProgramHelper 
{
	public static void DeveloperInformation()
	{
	System.out.println("This program was written by: Cameron Hall");
	System.out.println("Laboratory Exercise #1");
	System.out.println("TECH 2261");
	System.out.println("Data Structures");
	System.out.println("Spring 2020");
	System.out.println("The University of Memphis");
	}
	
	public static void ProjectDescription()
	{
		System.out.println("This program will create, sort, and search an array");
		System.out.println("of 45 elements that are randomly generated.");
	}
	
}
